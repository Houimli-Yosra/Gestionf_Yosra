﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestionf_Yosra.Model
{
    public class ActeurRole
    {
        public Personne Acteur { get; set; }
        public string role { get; set; }
    }
}
